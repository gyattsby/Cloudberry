# Cloudberry

A cozy study app where every study session is a flight. Spin the destination roulette,
prep at the boarding gate, focus with Pomodoro on a seat-back flight screen, then collect
passport stamps.

## Project facts

| | |
|---|---|
| **Type** | Static website (plain HTML + CSS + JavaScript, no framework) |
| **Vercel Framework Preset** | **Other** |
| **Build command** | `npm run build` |
| **Output directory** | `dist` |
| **Install command** | default (there are zero dependencies) |
| **Node version** | 18 or newer (Vercel default works) |
| **Environment variables** | **None needed** |
| **Backend / database / API keys** | **None.** All data is saved in the visitor's own browser (`localStorage`) |
| **External services** | Google Fonts (Fredoka, Nunito, Patrick Hand SC), loaded by the page at runtime. Nothing to configure |

These settings are already written into `vercel.json`, so Vercel picks them up automatically.

## Folder layout

```
cloudberry/
├── src/index.html        The whole app (CSS, JS, artwork, flags and stamps are all inside)
├── scripts/build.mjs     Build: syntax-checks the app's JavaScript, copies src/ -> dist/
├── scripts/serve.mjs     Tiny local preview server (no dependencies)
├── vercel.json           Vercel settings (output folder, build command, headers)
├── package.json          Build scripts
├── docs/CloudBerry_Handoff.md   Full feature spec and change history (not deployed)
└── .env.example          Confirms no environment variables are needed
```

## Run it on your computer (optional)

You need [Node.js](https://nodejs.org) 18+.

```bash
npm run build     # creates the dist/ folder
npm start         # open http://localhost:3000
```

`npm run dev` serves `src/` directly if you want to edit and refresh.

## Deploy to Vercel (beginner steps)

Vercel does not accept a ZIP upload directly, so first **unzip this folder**. Then pick ONE method.

### Method A: GitHub + Vercel dashboard (recommended, gives automatic updates)

1. Create a free account at <https://github.com> and <https://vercel.com> (choose "Continue with GitHub").
2. On GitHub, click **+ > New repository**. Name it `cloudberry`, leave it empty (no README), click **Create repository**.
3. On the new repo page click **uploading an existing file**, then drag in **everything inside** the unzipped folder
   (`src`, `scripts`, `docs`, `package.json`, `vercel.json`, `README.md`, `.gitignore`, `.env.example`).
   Click **Commit changes**.
4. In Vercel, click **Add New... > Project**, find your `cloudberry` repo, click **Import**.
5. On the settings screen everything should already be filled from `vercel.json`:
   Framework Preset **Other**, Build Command `npm run build`, Output Directory `dist`.
   Do not add any Environment Variables. Click **Deploy**.
6. After about 30 seconds you get a live link like `https://cloudberry-xxxx.vercel.app`.

To update later: change `src/index.html` on GitHub (pencil icon > Commit). Vercel redeploys on its own.

### Method B: Vercel CLI (no GitHub needed)

```bash
npm install -g vercel
cd cloudberry          # the unzipped folder
vercel                 # log in, accept the defaults, creates a preview link
vercel --prod          # publishes to your real .vercel.app address
```

## After it is live

- **Your saved passport and stamps do not move automatically.** Browser data belongs to one web address.
  On your old Claude artifact link: Settings > Backup and restore > Copy.
  On the new Vercel link: Settings > Backup and restore > paste and Restore.
- Visitors each have their own private data (it lives in their browser, not on a server).
- The wake-lock feature (keeps the screen on while flying) works because Vercel serves the site over HTTPS.
- Custom domain: Vercel project > **Settings > Domains**.

## Troubleshooting

- **Build fails with "JavaScript syntax error"**: the build script checks the app's code before shipping.
  The message tells you which problem it found; fix `src/index.html` and push again.
- **404 on the live site**: check Vercel > Project > Settings > General > Output Directory is `dist`.
- **Fonts look different**: Google Fonts is blocked on that network; the app falls back to system fonts.

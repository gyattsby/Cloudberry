# Cloudberry: Handoff File

Keep this file together with `cloudberry.html` (the complete app source). To continue in a new chat, attach both and say: "Continue Cloudberry from the handoff."

Last updated: 2026-11-26 (Asia/Manila), M0-M35 complete (M35 = removed the Time lapse streak note), M0-M34 complete (M34 = Save my passport button removed, bear removed from the empty Flight screen), M0-M33 complete (M33 = every passport print is followed by an approval and stamp), M0-M32 complete (M32 = After you land button removed from the boarding gate), M0-M31 complete (M31 = passport is not stamped by the printer, enlarged map can be explored (drag, pinch, wheel, +/-/Fit), map always fits the frame), M0-M30 complete (M30 = passport printed blank then stamped, bubble pop on visa delete, logo on landing routine, checks auto-clear after a flight, Clear checks button removed), M0-M29 complete (M29 = mobile passport keeps desktop size, ticket codes with country, bigger flight map on phones, Vercel-ready), M0-M28 complete (M28 = visa delete plays a paper ripping sound), M0-M27 complete (M27 = time lapse removed, crumple sound), M0-M26 complete (M26 = flight screen: map enlarge, layover pins, pomodoro on roulette), M0-M25 complete (M25 = delete visas, stamps back on visa pages), M0-M24 complete (M24 = clear checks, no passport stamping, real ticket ratio), M0-M23 complete (M23 = visa page with ticket stamped in the center), M0-M22 complete (M22 = plane transition, resize-proof ticket, auto start), M0-M21 complete (M21 = 4-item follow-up), M0-M20 complete (M20 = 8-item polish pass), M0-M19 complete (M19 = 11-item polish pass), M0-M18 complete (M18 = boarding ticket, aisle walk animation, Change countries button); M0-M17 complete (M17 = longer focus choice, break popups, passport animation, new mode logos); M0-M16 complete (M16 = change country, blueberry hub and arrow, pixel profile pictures, blueberry stamps, mode logos, flat flags, to-do panel; version 9)
Owner: Sophia Pangilinan (BSIT student, ERP track). Her vibe: cats, cute stuff, bear + clover motif, cream and ochre palette.

## Standing instruction from Sophia
After every milestone, update this handoff file completely and re-send it, so she has a copy even if the chat runs out of context.

## The original request
Make a website/app for studying called **Cloudberry**.

1. A roulette for travel countries/destinations around the world.
2. The user picks the country they are from and locks it, so the app never asks again.
3. A study session is a flight from the home country to the roulette's destination.
4. If the session is 3 hours or more, add stopovers in different countries, depending on how long they studied.
5. Pomodoro is used for the timing.
6. A cute, themed seat-back flight screen (like the airplane screens showing time until landing) with the plane moving toward the destination.
7. Pre-flight to-do lists as little "stations" (cleaning, studying, other things). Clean desk gets a 10-minute timer. Not only for studying.
8. Stations requested: Snack Stop, Laundry Boarding, Cozy Cabin, Lucky Start, Landing Routine, "add more if you can."

## Milestone status
| Milestone | What | Status |
|---|---|---|
| M0 | Handoff file with full spec | DONE |
| M1 | Build `cloudberry.html` with every feature below; syntax check and planning-logic test | DONE |
| M2 | Publish as an artifact and final handoff update | DONE |
| M5 | Searchable country, passport onboarding, student/worker/both tailoring, photo upload, exclusive focus modes | DONE (tested headless) |
| M4 | Real passport booklet, passport check before booking, focus-first boarding gate | DONE (tested headless) |
| M3 | Theme picker (default Sakura), passport profile (student or not), flight screen shows a real world map | DONE (syntax-checked, not yet viewed in a browser) |
| M6 | Boarding gate redesign: prep timer ring + illustrated station tiles | DONE |
| M7 | Blueberry logo embedded | DONE |
| M8 | Ocean Blue theme; boarding gate flow mode > categories > timer | DONE (tested headless) |
| M10 | Buddy stamp on every landing (early too) and animated into the visa pages; approved stamp higher; photo upload before buddy picker; time lapse button on the flight screen | DONE (tested headless in sandboxed iframe) |
| M11 | Visa stamp on the right, Blueberry theme is the default, 8 cute passport pictures to pick when no photo is uploaded | DONE (tested headless) |
| M12 | One searchable country picker with flag images, flags are images everywhere, name required, 11 new station icons, boarding gate shows categories first | DONE (tested headless) |
| M13 | Boarding gate: Productivity / Work Mode > station list (no timer) > station page with timer + to-dos; logo in wheel hub; new blueberry plane; approved stamp lower | DONE (tested headless) |
| M14 | Station page: thin timer ring left, to-dos as illustrated emoji tiles with checkbox + handwritten label on the right | DONE (tested headless) |
| M18 | Ticket shown with passport, aisle-walk animation to the seat, roulette Change countries button | DONE (tested headless) |
| M9 | Buddy stamps (required buddy), blueberry APPROVED stamp on passport, stamping animation, country dropdown, logo on passport form, Ocean Blue default | DONE (tested headless in sandboxed iframe) |

## What is built (all in one file, `cloudberry.html`)
Single self-contained HTML page. No libraries, no build step. Fonts from Google Fonts (Fredoka for headings, Nunito for text).

**Screens** (hash routes `#boarding`, `#roulette`, `#flight`, `#landing`, `#passport`; first-run shows the setup screen):
1. **Setup**: choose home country from 82 countries, then "Lock in my home country". Saved, never asked again. Unlock lives in Settings (two-tap confirm).
2. **Boarding gate**: 12 stations in 4 groups. Each opens a sheet with a checklist (tick, delete, add your own steps) and, where relevant, a timer. A station is "Stamped" when all steps are ticked. Everything resets each new day (custom steps are kept).
   - Tidy up: Clean Desk (10 min timer), Laundry Boarding (10 min), Cozy Cabin (10 min), Cat & Plant Check
   - Take care of you: Snack Stop (5 min), Fresh-Up Lounge (5 min), Stretch Lounge (5 min)
   - Get ready to focus: Carry-On Check, Airplane Mode (phone), Boarding Music, Lucky Start (three things to accomplish today, with tick boxes)
   - After you land: Landing Routine (opens the Landing screen)
3. **Roulette**: a spinning wheel of 10 random destinations (never the home country). Result card shows distance, real flight time (distance / 850 km/h + 30 min), and a study-length picker: 30 min, 1 h, 2 h, 3 h, 4 h, 6 h, or "Real flight" (capped 12 h). "New destinations" reshuffles the wheel. "Board this flight" creates the session.
4. **Flight (seat-back screen)**: dark bezel, sky map with sun, drifting clouds, hills, dotted route arc, a plane (with a tiny bear in the window) moving along it, a berry-colored trail, and flag pins for origin, layovers and destination. Tiles: Landing in (H:MM:SS), distance to go, altitude (climb, cruise, descend, 0 at layovers), ground speed, "Now over" (nearest country to the plane's great-circle position), next stop. Pomodoro ring with block countdown and a cabin announcement line. Buttons: Take off, Pause/Resume, Land early (two-tap). Chime and toast at each block change. Screen wake lock requested while flying.
5. **Landing**: arrival stamp, stats (focus time, blocks, layovers, km), Lucky Three review (tick), Landing checklist, note box, "Save my progress". The flight is recorded to the passport automatically on landing; saving adds the review.
6. **Passport**: totals (flights landed, focus time, countries visited, km flown) and a stamp card per flight or day log.
7. **Settings**: home country unlock, sounds, fast-forward preview (60x, for trying the screen), backup (copy and restore JSON), erase everything (two-tap).
- A green pill in the header shows the flight countdown (or a running station timer) when you are on another screen.

## M3 changes
- **Themes**: Settings > Theme. Cloudberry (original cream/ochre), Sakura (pink; was the default until M9), Matcha, Lavender, Night. Stored in `prefs.theme`; applied by `applyTheme()` on the `<html data-theme>` attribute. Theme tokens are the `:root[data-theme=...]` CSS blocks.
- **Passport profile**: `S.profile = {name, status:'student'|'other', detail, avatar}`. Created from the Passport screen (card at top) or Settings. Form asks name, "Are you a student?", what they study or do (label changes with the answer), and a buddy emoji. Sheet is `profileSheet()`, submit handled in the `data-form="profile"` branch.
- **Flight map**: the dotted arc is gone. The seat-back screen draws a coarse hand-drawn world map (`LAND` polygons, equirectangular, 10 units per degree) with a graticule, zoomed to fit the route. The real great-circle route is a dotted line, the plane follows it (rotating along the path), a berry trail fills behind it, and flag pins mark origin, layovers and destination. Longitudes are unwrapped so routes across the date line work. Code: `setupMap`, `MAP`, and the plane/trail part of `updateFlight`.

## M4 changes
- **Boarding gate asks first**: "What do you need to focus on today?" with two cards: Chores & productivity, or School & other stuff (`MODES`, saved as `S.board.mode`, resets daily). Only that mode's stations show, grouped in collapsible sections (first one open). "Change" chip re-asks.
- **Passport looks like a real one**: cover, identity page (photo = buddy emoji, name, passport no. `CB#######`, nationality = home country, issue date, type, studying/doing, MRZ-style lines), then "Travel record" and "Visa pages" (stamps). `ppPage()` builds the identity page. Profile now also stores `no` and `ts` (issued).
- **Save my passport**: draws the identity page to a canvas and shows it as an image; the user presses and holds (or right-clicks) to save it (real downloads do not work in published artifacts).
- **Passport control before booking**: "Board this flight" now calls `boardFlight()`, which opens the passport application if no profile exists (`PENDING` flag), then a "Passport control" sheet with "Show passport and board". Only that button calls `doBoard()` (the old board logic).
- Headless test passed: pick focus, apply for passport, check, board, passport page, save image, no errors.

## M5 changes
- **First-run flow**: type to search your country (filtered list, pick it) > Lock in > **Fill out your passport** (required; `route()` guard `renderOnboard()` blocks everything until `S.profile` exists) > boarding gate.
- **Passport profile fields**: name; "student, working, or both?" (`status` = student | worker | both; old 'other' migrates to worker); school and course (`detail`) shown for student/both; job and workplace (`work`) shown for worker/both; passport photo = uploaded picture (`photo`, resized to 240x300 JPEG data URL) or a buddy emoji (`avatar`). Identity page and the saved image show only the fields that apply (`ppFields`).
- **Focus modes are now exclusive** (`MODES`): Chores & productivity = Clean Desk, Laundry, Cozy Cabin, Cat & Plant, Fresh-Up. School & work (renamed) = Carry-On, Airplane Mode, Boarding Music, Lucky Start, Snack Stop, Stretch Lounge. Landing Routine is in both (shared end-of-flight step).
- **Tailored checklists** (`TAILOR`, `applyRole`): Carry-On, Airplane Mode, Lucky Start blurb, and Landing Routine items change for student, worker, or both. Changing the role resets those stations' items for today.
- Headless test passed: search, lock, onboarding, photo upload, both-role form, mode lists, tailored items, passport, saved image.

## M6: boarding gate redesign (from Sophia's reference screenshot: study-with-me style)
After choosing a focus category, the boarding gate is one board: a big **prep timer ring** on the left (5, 10 or 15 min presets, Start/Pause/Resume, Reset; `PREP`, `updatePrep`, ticked in `tick()`, chime and toast at zero) and on the right **illustrated station tiles** with a checkbox and handwritten-style label (font Patrick Hand SC, `--hand`). Tapping the picture or label opens the station's checklist sheet; ticking the checkbox marks all its steps done (Lucky Start opens its sheet instead). Landing Routine is a chip below. The tiles currently use big emoji as the "drawings"; custom doodle SVGs would be the next polish step. Old collapsible station cards (`.station`, `details.group`) are no longer used.

## M7: logo
Sophia's blueberry illustration is the logo. It is embedded once as a base64 PNG (`LOGO` const in the script, transparent background, 200px wide) and shown in the header brand button, the welcome screen, and the passport cover (`img.logo`; the header img gets its src in `init()`). A 64px version is set as the page's favicon link in `init()`. The old SVG berry in the header was removed. The original image is not stored in the repo; the embedded copy is what the app uses.

## M8: Ocean Blue theme and category step
- **Themes now**: Cloudberry, Sakura, Matcha, Lavender, Blueberry (periwinkle, `blue`), **Ocean Blue** (true sky blue, `ocean`, the default since M9), Night. Added a `:root[data-theme="ocean"]` token block and an entry in `THEMES`.
- **Boarding gate flow**: 1) pick focus mode (Chores & productivity, or School & work); 2) the gate shows only **category cards** (the mode's groups, minus "After you land"), each with its station emojis, station names and a progress bar; 3) tapping a category opens the **prep timer board** with only that category's station tiles. A "‹ Categories" chip goes back; "Change" on the category screen re-picks the mode.
- Stored as `S.board.cat` (index into the mode's categories); cleared when the mode changes and at the start of each new day. Handlers: `setCat`, `backCats` in `ACT`. Category screen CSS: `.cats`, `.cat`.
- Categories now: Chores = Reset your space (Clean Desk, Laundry, Cozy Cabin, Cat & Plant), Reset yourself (Fresh-Up). School & work = Get ready to focus (Carry-On, Airplane Mode, Boarding Music, Lucky Start), Fuel up and stretch (Snack Stop, Stretch Lounge). Landing Routine stays as a chip at the bottom of both screens.
- Headless test passed: mode > 2 category cards, no timer; category > timer + 4 tiles, timer counts down; back to categories; chores mode; Ocean theme renders; no errors.

## M9: buddies and stamps (from Sophia's stamp artwork)
- **Buddy stamps**: Sophia supplied 7 "FLIGHT COMPLETED" stamps plus one blueberry "APPROVED" stamp. They are embedded in the script as transparent WebP data URLs in `STAMPS` (cat, puppy, seal, owl, bunny, penguin, clover, approved; about 420px wide). Two of the originals (cat, puppy) had black glowing backgrounds; their background was removed by texture masking, so they look like ink on paper like the rest. `FACES` holds 160x200 head crops of each buddy, used as the passport photo when no photo is uploaded. Original images are not stored in the file; the embedded copies are what the app uses.
- `BUDDIES` = `[key, name]` list (Kitty, Puppy, Seal, Owl, Bunny, Penguin, Clover). Helpers: `budKey`, `budName`, `budFace`.
- **Picking a buddy is required**: the passport form has a buddy grid (radio `name="buddy"`, label `.bud`). Submitting without one shows `#pf-err` and stops. Saved as `S.profile.buddy`. The emoji avatar picker was removed (`AVATARS` is unused; `avatar` is kept only for old data). Older profiles without a buddy are sent back to the passport form (`route()` guard and `boardFlight()` check `S.profile.buddy`); the form is prefilled.
- **Approved stamp**: always shown on the passport identity page (`.appr` inside `ppPage(pr, anim)`), and drawn on the saved passport image. After "Get my passport" during onboarding, `issuedView()` shows a "Passport approved!" screen where the stamp is stamped with the animation, then "Go to the boarding gate" (`toBoarding`). If the passport is applied for from the boarding check, `checkSheet(true)` plays the animation.
- **Flight completed stamp**: each landed flight entry stores `buddy` (in `recordLanding`). A completed landing shows that buddy's stamp in the landing hero, stamped with the animation once (`entry.stamped`, `STAMPNOW` keeps it through the double render caused by the hashchange). Early landings keep the old flag stamp. Visa pages show the buddy stamp for completed flights.
- **Stamping animation**: `stampHTML(src, alt, anim)` returns a `.stampw` with the ink image; with `anim` it adds a rubber-stamp tool (`TOOLSVG`) that drops, presses, and lifts (`@keyframes toolPress`, `inkIn`, 1.5 s) and plays a thump sound (`thump()`, respects the sound setting). Reduced-motion users get no animation.
- **Country picker**: type to search (as before) OR choose from a `<select id="home-select">` list of all countries. Picking from either fills both.
- **Fill out your passport** screen now shows the blueberry logo.
- **Default theme is Ocean Blue** (`defaults()` and `applyTheme()` fall back to `ocean`). People who already picked a theme keep theirs.

## M10 changes
- **Approved stamp** sits higher on the identity page (`.appr` bottom 46px, right 14px) and on the saved image (centered at 790,350, 210px wide).
- **Buddy stamp on every landed flight**: early landings now also get the buddy stamp (faded, class `early`) instead of the flag stamp. Landing text says "<Buddy> stamped your passport" with a "See my stamps" chip.
- **Stamped into the passport**: on the Passport screen, the newest flight not yet shown there (`entry.ppStamped`) is stamped with the animation on its visa card (`PPNOW`). All visa cards for flights show the buddy stamp (`stampHTML(..., 'vstamp')`).
- **Passport form order**: name, status, school/work, passport photo (upload or "Use my buddy instead"), then the buddy grid (required), then the button.
- **Time lapse**: a "⏩ Time lapse" button in the flight controls (also before takeoff; it takes off for you). It sets `sess.lapse`; `applyElapsed` then runs at `lapseRate(sess)` = whole flight in about 40 seconds (at least 60x). Press "▶ Normal speed" to go back. The Cabin tile says "Time lapse". Flights that used time lapse (or the 60x preview setting) are recorded with `lapse:true` and tagged "⏩ Time lapse" on their visa card, because their focus time is not real. Tested: the plane moves along the route during time lapse and lands on its own.

## M11 changes
- **Visa stamp on the right**: flight visa cards are now two columns (`.visa.flt`): text in `.vtxt` on the left, the buddy stamp on the right (112px). Passport grid min card width is 300px.
- **Blueberry is the default and main theme** (`blue`; `defaults()` and `applyTheme()` fall back to it). `prefs.themeV=2` migrates anyone still on the old default Ocean Blue to Blueberry once; other chosen themes are kept.
- **Passport picture picker**: Sophia's 8 cards (puppy, kitty, seal, owl, bunny, penguin, blueberry, clover) are embedded as `PICS` (180x220 WebP data URLs), listed in `PICLIST`. The profile form shows them as a radio grid (`name="pic"`, `.buds.pics`); saved as `S.profile.pic` (default `blueberry`). Passport photo order: uploaded photo (`photo`) > chosen picture (`pic`) > buddy face. Helpers `photoHTML`, `photoSrc`; the saved passport image uses `photoSrc`. "Use my buddy instead" became "Remove my photo".
- Known: on very narrow phones the APPROVED stamp can overlap the Studying field on the identity page.

## M12 changes
- **Flags are images** (`FLAGS` = 64x48 WebP data URLs per ISO code, rendered from the Noto flag set; Windows shows letters for emoji flags). `c.flag` is now an `<img class="fi">` HTML string (use innerHTML, never textContent); SVG spots use `flagSVG(c,x,y,w)` (wheel, map pins, landing stamp). Passport image canvas shows the country name only.
- **One country picker**: the text box and dropdown are merged into a single combobox (`#home-combo`): tap it or the arrow to see all countries with flags, or type to filter; arrow keys and Enter work. `comboList`, `comboClose`, `pickHome`. The old `<select id="home-select">` is gone.
- **Name is required** on the passport form (`#pf-nerr` error); no more default "Traveler".
- **Boarding gate**: no focus-mode question anymore. The gate opens on the 4 categories (`ALLCATS`: Reset your space, Reset yourself, Get ready to focus, Fuel up and stretch) with one emoji each (`CATEMO`, placeholders until Sophia sends logos). Picking one shows the prep timer + station tiles. `MODES`/`setMode`/`changeMode` are now unused except as data for `ALLCATS`.
- **Station icons**: 11 icons from Sophia's badge sheet embedded as `SICON` (transparent WebP, labels removed), shown on the tiles and in station sheets via `stIcon()`. Landing Routine still uses its emoji.

## M13 changes (supersedes the M12 boarding gate description)
- **Boarding gate has 3 levels**: (1) two cards, **Productivity** (`MODES.chores`: Clean Desk, Laundry, Cozy Cabin, Cat & Plant, Fresh-Up) and **Work Mode** (`MODES.school`: Carry-On, Airplane Mode, Boarding Music, Lucky Start, Snack Stop, Stretch Lounge); (2) a list of that mode's stations as cards with icon, blurb and progress, no timer; (3) tapping a station opens its page: prep timer ring (5/10/15 min, starts at the station's own timer or 10) plus its to-dos inline (`stationBody`, tick/delete/add; Lucky Start shows its three inputs). State: `S.board.mode`, `S.board.st` (reset daily). Actions: `setMode`, `setSt`, `backSt`, `changeMode` (Back). `ALLCATS`/`CATEMO`/`setCat` are now unused. Landing Routine chip and the Spin button stay at the bottom.
- **Roulette hub** shows the blueberry logo (`LOGO`) instead of the old berry drawing.
- **Plane**: `PLANEIMG` (WebP data URL cut from Sophia's blueberry plane, nose pointing right) drawn by `planeSVG()` as an `<image>`; rotation logic unchanged. The old bear-in-window plane is gone.
- **Approved stamp** sits lower (`.appr` bottom 26px; saved image y=372).

## M14 changes
- **Station page (level 3 of the boarding gate) now matches Sophia's reference**: timer ring on the left (thinner, handwritten digits), and on the right each to-do is a tile: big emoji "drawing", checkbox, handwritten uppercase label (`todoTiles`, `.ptile .art.emo`, `.todo` grid). Tapping the emoji, checkbox, or label toggles it (`itemCheck`); a small × removes a step (`delItem`); "Add your own step" stays below. Lucky Start shows three 🍀 tiles with text inputs (`luckyTick`).
- **Emoji per to-do** come from keyword matching on the step text (`ITEMEMO`, `itemEmoji`); custom steps get ✨. Sophia will supply logos later: swap `itemEmoji` for an image lookup (same pattern as `SICON`/`stIcon`).

## M15 changes (supersedes anything above about themes)
- **One look only: Blueberry.** All other themes, the theme picker in Settings, and Night/dark mode (including the prefers-color-scheme rule) were removed. The Blueberry tokens are now the plain `:root` block. `applyTheme()` is a no-op kept for old calls; `prefs.theme` is ignored.
- **New artwork re-cut from Sophia's two new sheets**: `SICON` (the 11 station badges: desk, laundry, cabin, pets, fresh, carryon, airplane, music, lucky, snack, stretch; transparent WebP, labels removed, bow kept) and `PICS` (the 8 passport picture cards, 180x227 WebP with rounded corners). Same keys as before, so no code changes were needed.
- **Plane trail is blueberry** (`#3B4CC0`, 6px) in `#f-trail`.
- **Small country labels on the flight map**: in `setupMap`, up to 18 other countries (never the origin, stops or destination) get a tiny dot plus a name with a white outline (`.clabel`, 10px scaled by the map zoom, 85% opacity). Labels are placed greedily and skip anything overlapping a pin or another label, so the destination stays the focus (its flag and city name are still the biggest text).
- Tested headless: Philippines to Japan flight with time lapse, no console errors.

## M16 changes
- **Change country after spinning**: result card has "Change country" (and the pre-spin card "Pick a country"); opens a searchable sheet (`destSheet`, `destList`, `ACT.pickDest/chooseDest`) that sets `S.wheel.result`.
- **Wheel**: hub shows one drawn blueberry (inline SVG in `wheelSVG`); pointer is Sophia's blueberry triangle (`ARROW`, `.pointer` img).
- **Profile pictures** (`PICS`) are the new pixel-art cards; **buddy stamps** (`STAMPS`, not `approved`) are recolored blueberry blue. "(required)" removed from the buddy heading; the check still applies.
- **Mode logos** (`MODELOGO`, `mlogo(k,cls)`): coffee and cake = Productivity (`chores`), pointing hand and briefcase = Work Mode (`school`); shown on the two mode cards, the station list header and beside the station title.
- **Flags** are now flat 3:2 rectangles drawn as SVG data URLs (`FLAGS`, 82 countries, simplified emblems, thin outline); `flagSVG` uses 3:2 height.
- **Station page** right side is a panel: logo + title + blurb, checkbox rows with x, "Add your own step" + Add (`todoRows`, `.trow`). Old `todoTiles` is unused.

## M17 changes
- **Longer focus**: pressing Take off (before the flight starts) opens a sheet: Classic 25 min or Longer 50 min (`focusSheet`, `ACT.setFocus`). It re-plans the segments with `planFlight(from,to,total,F)` / `buildSegments(total,F)`. Longer = 50 focus + 10 break; on flights of 180 min or more every break is a **layover** (stopover country), under 180 min they are normal 10 min breaks. Classic is unchanged. Stored as `sess.focusLen`, `sess.asked`. Time lapse skips the question.
- **Break popup** (`breakSheet`, in `announce`): at each new break or layover a sheet shows a kaomoji, an encouragement (`ENC_A` x `ENC_B` = 625 unique messages, walked in a scrambled order by `prefs.encN`/`encOff` so it changes every break and never repeats back to back), a second kaomoji, and 3 break ideas from `BREAKTIPS` (40). Layovers add a welcome line for the country. Shown inside the flight (seat-back) screen as an overlay card (`.fbrk`, `BRKCARD`, `showBrk`) with an x button (`ACT.closeBrk`), also during time lapse. Replaced by the next break's card; cleared when the next focus block starts. If the person is on another tab, a toast says to open the Flight tab.
- **Passport animation** (`passportAnim`): "Show passport and board" plays a 3 second overlay: the booklet rises, the cover flips open, the APPROVED stamp thumps in, then the flight is created. Skipped for reduced-motion users.
- **Boarding gate**: removed the "Done prepping? Spin" box and the "Ready? Spin" button (the steps count stays). New mode logos (blueberry coffee and cake, hand and briefcase; black backgrounds removed). The logo beside the station title is now the station's own icon.
- **Wheel hub** is a rounded, soft blueberry-colored star (no berry): two stacked polygons with round joins (dark outline, light periwinkle fill).

## M18 changes
- **Ticket**: passport control now shows a boarding pass under the passport (`ticketHTML(id)`, `ticketData(id)`; route codes from city names, flight no, gate, seat, date, study time, barcode stub). Button reads "Show passport and ticket". The ticket id is `NEXTID`, set in `checkSheet` and reused by `doBoard` as `session.id`, so the ticket seat and flight number match the seat-back screen (`flightNo`, `seatNo`).
- **Boarding animation** (`passportAnim`, about 11 s, "Skip" button top right): 1) passport book opens and gets the APPROVED stamp; 2) the ticket slides in, a scan line sweeps it, a BOARDED stamp thumps in; 3) **aisle walk** (`aisleHTML`, `runAisle`): top-down cabin with 6 seats per row and an aisle, the blueberry logo walks down the aisle (rAF, live "Row N" label, ease in/out), sidesteps into the ticket seat, the seat turns gold, chime. Then the flight is created. Reduced-motion users skip all of it.
- **Roulette**: "Pick a country" and "Change country" are removed from the buttons. One button, **Change countries** (`ACT.reshuffle`), swaps the wheel's 10 countries for a new random set (also clears the current result); it is on the pre-spin card and the result card. `destSheet`/`pickDest`/`chooseDest` are still in the code but unused.

## M19 changes (11-item polish pass)
1. **Bear removed** from the empty Passport (visa pages) card. (Bear still on the Landing hero and empty Flight screen; not asked.)
2. **Wheel hub star** is a soft, pillowy rounded star (`softStar(R,r)` quadratic-smoothed path).
3. **Ticket** uses real IATA codes (`IATA` map by city: Manila MNL, Tokyo NRT, ...), name as SURNAME/FIRST (`paxName`), date `25 NOV 2026`, boarding time, booking ref (`pnr`), class, and the study task.
4. **Sitting character**: Sophia's blueberry (bg removed, `SITCHAR`) walks the aisle with a waddle and stays seated (hop) in the seat (`.achar`, `runAisle`).
5. **Pick a country manually**: "Pick a country" button is back on both roulette cards (`ACT.pickDest/chooseDest`).
6. **Map**: hand-drawn finer coastlines (`LAND` ~57 polygons, Chaikin-smoothed by `smoothPoly`; `WATER` = Black Sea, Caspian, Great Lakes, Lake Victoria; not survey data, no map data was reachable offline) and **day/night shading** (`sunPos`, `updateNight`, `#f-night`, real clock, refreshed each minute).
7. **Task label**: input on the roulette result card (+ quick chips), editable "Working on" bar on the flight screen (`sess.task`), saved to passport entries (`entry.task`), shown on visa cards, landing, and ticket.
8. **Passport**: "This week" streak card (Mon-Sun, `studyDays`, `streaks`, time-lapse flights excluded) and "World progress" card (countries x/82, by continent `CONT`, mini map, visited flags).
9. **Custom pomodoro**: sheet has Classic 25/5, Longer 50/10, Deep 90/15 and custom focus/break inputs (`applyFocus`, `buildSegments(total,F,B)`). Breaks of 10+ min on 3h+ flights are stopovers; under 10 min keep the long break every 4th block (3x break). A "Timer 25/5" button on the pre-takeoff controls reopens the sheet without starting.
10. **Destination local time** tile on the flight screen (`TZ` IANA map, `localHTML`, shows offset from home and tomorrow/yesterday).
11. **Break volume** slider (`prefs.brkVol`, default 50 = old loudness, 0 = silent) in Settings, on the flight screen and on the break popup; applies to break/focus-change chimes via `chime(scale)`.

## M20 changes (8-item polish pass)
1. **Passport printing animation** (`printPassport(done)`): every time the passport details are saved (first issue, edit, or before boarding) a printer overlay prints the identity page out of a slot (about 3.7 s, Skip button, printer sound `printSound`). Then the old flow continues (approved screen, passport control, or toast).
2. **Ticket prints before the check**: in the Passport control sheet the ticket slides out of a printer slot (`.prt`, `.prt-slot`, `.prt-paper`) with printer sound.
3. **Cute stars on the roulette** (`starBurst()`, `.star`): gold, pink, blue and green stars pop out of the arrow when the wheel lands and when a country is picked manually.
4. **Boarding gate timer first**: to-dos stay locked (dimmed, with a hint and a toast) until the prep timer has been started (`PREP.started`, `prepStarted`, `needTimer`). When every to-do of a station is ticked, `maybeAdvance` moves automatically to the next unfinished station (or back to the list with a toast when all are done).
5. **No emoji** on the "What will you study or work on?" quick chips, the flight "Working on" label, the task tag on visa cards, and the Pick a country button.
6. **BOARDED stamp** is bigger, sits lower in the ticket (left 40%, top 89%) so it no longer covers the details.
7. **Landing screen**: "Your lucky three" card and the "Where did you stop?" note were removed (the data fields remain in state, unused).
8. **Visa stamps**: when a new flight stamp reaches the passport (`centerStamp`), a big animated stamp shows in the middle of the screen for about 3 s, then fades. **World progress card removed** from the Passport (`worldCard` is unused).
Tested headless: no script errors; fonts only fail to load offline.

## M21 changes (4-item follow-up)
1. Finishing every to-do of the selected station now goes straight to the Roulette (`maybeAdvance` sets `location.hash='roulette'`); no more auto-jump to the next station.
2. Printers are wider than the paper: `.prt-slot` is 100% wide and 22px tall, `.prt-win` (the paper) is 90%. Same for the passport printer overlay and the ticket printer in the passport control sheet.
3. BOARDED stamp is dead centre of the ticket (left/top 50%), semi-transparent so details stay readable, font scales with `clamp`; a `max-width:480px` media block shrinks the ticket for phones. Tested at 1000px and 375px.
4. New "Ready to start?" sheet (`readySheet`, `ACT.readyYes`) appears before the passport and ticket are shown, since the flight starts as soon as they are shown. "Not yet" closes it. It also follows the passport-printing step when the passport is created at boarding.

## M22 changes (4-item follow-up)
1. **Airplane transition** (`planeTransition(mid)`, `.pt-ov`): the blueberry plane flies across a sky screen. Used when a station's to-dos are all ticked (to the Roulette) and after the boarding animation (to the Flight screen).
2. **Ticket back to full width** (same width as the passport); only its printer is wider (`.prt.tk .prt-slot` = ticket width + 28px). The passport printer overlay keeps the paper at 90% of the printer.
3. **Resize-proof ticket**: `.tkt` is a CSS container (`container-type:inline-size`) and all its text, padding, stub and BOARDED stamp use `cqw` units, so it keeps identical proportions at any width (tested 320, 375, 1000 px). The old phone media block was removed.
4. **Flight starts right after the transition**: `showPassport` runs `planeTransition` then `doBoard(); route(); takeOff()`; the Take off button and Pomodoro sheet are skipped. `doBoard` uses the last chosen focus/break lengths (`prefs.lastF/lastB`) or Classic 25/5.

## M23 change
**Visa stamp on the ticket**: `centerStamp(p)` now shows a visa page in the middle of the screen (header "VISA - city", the flight's ticket from `ticketHTML(p.id,p)`, built from the passport entry via the new optional `e` argument of `ticketData`/`ticketHTML`) and the buddy stamp is pressed onto the middle of it with the stamping animation. It stays about 3.6 s, then fades. Works at phone and desktop width.

## M24 changes
1. **Clear checks** button on the station page (`ACT.clearChecks`) unticks every to-do of the open station (and the Lucky three).
2. **Passport visa pages are no longer stamped**: no stamp image on the visa cards and no pop-up on the Passport screen. The big centered visa + ticket stamp (`centerStamp`) now plays on the Landing screen the first time a landed flight is shown (landing hero stamp is static then).
3. **Realistic ticket**: about 2.4:1 like a real boarding pass (4-column field grid, narrower stub, no wrapping, date shows day and month only, labels "Ref" and "Study"). Still scales with `cqw` units.

## M25 changes (supersedes M24 item 2 and M23)
1. "What will you study or work on?" field and chips removed from the roulette result card (the flight screen "Working on" bar remains).
2. **Delete visa pages**: tap a visa card on the Passport to select it; a "Delete this visa" button appears at the bottom of the card (two-tap confirm). `VSEL`, `delRow`, `ACT.visaSel/delVisa`. Works for flights and day logs.
3. Landing shows just the buddy stamp in the hero (animated once); the centered visa + ticket pop-up (`centerStamp`) is no longer called anywhere.
4. Visa pages show the buddy stamp on the right again (static, no animation).

## M26 changes
1. **No layover text when there are none**: the roulette card only mentions layovers when the plan has them; the Landing "layovers" stat is hidden at 0; the flight screen "Next stop" tile only exists when there are layovers.
2. **Pomodoro choice on the roulette**: chips Classic 25/5, Longer 50/10, Deep 90/15 and Custom (focus/break inputs) on the result card (`ACT.setPomo/pomoCustom/setPomoCustom`, stored in `prefs.lastF/lastB`, used by `doBoard` and the preview plan). Layover/stop preview follows the chosen timer.
3. **Break volume only in Settings**: removed from the flight screen and the break popup.
4. **Layovers on the right spot**: the route is now piecewise through the real layover countries (`rp()` in `setupMap`, `MAP.rp`), pins sit on each country's real coordinates, and the plane parks exactly on the pin during a layover.
5. **"Working on" bar removed** from the flight screen.
6. **Enlarge map**: tap the map (or the Enlarge/Shrink button) to make it big (`FBIG`, `applyBig`, `ACT.mapBig`, recomputed on resize via `MAPASP`). The focus ring and Landing-in time shrink into a compact box at the top-left of the map; other tiles hide until you shrink it.

## M27 changes
1. **Time lapse removed**: no button on the flight screen and no "Fast-forward preview" in Settings. Flights always run at real speed (`applyElapsed` ignores `lapse`/`prefs.ff`; the old `ACT.lapse` code remains unused). Old passport entries tagged time lapse still show their tag.
2. **Crumpled paper sound** (`crumple()`, filtered-noise crackles) plays when a visa is deleted (respects the sound setting). Replaced in M28.

## M28 changes
1. **Visa delete now sounds like paper ripping**: `crumple()` was replaced by `ripPaper()`. It builds a 0.5 s noise buffer in code (one sharp snap, a single rasping pull, random fibre pops, fade out) and plays it through a high-pass and a rising band-pass filter at half the original volume (output gain 0.275). Called from `ACT.delVisa`; respects the Sounds setting. No audio files are used.

## M29 changes
1. **Passport looks the same on phones as on desktop.** `.idpage` is now a CSS container (`container-type:inline-size`) and every size inside it (header, photo, fields, MRZ lines, APPROVED stamp) is `calc(N*var(--u))` where `--u:min(1px,.2128cqw)`. At 470px wide or more `--u` is 1px, so desktop is unchanged; below that the whole passport shrinks proportionally (no wrapping, no overlap). The idpage must keep `width:100%` (a container cannot size itself from its content). Same idea as the ticket's `cqw` units (M22). Block is at the end of the main `<style>`.
2. **Ticket route**: each side now shows the airport code, the city and the country name under it (`small.ct`), left side left-aligned and right side right-aligned, long names are cut with an ellipsis. All 82 cities already have a real IATA code in `IATA` (checked: none missing, none duplicated, none made up). Real codes do not always look like the city (Bangkok is BKK, not BNK; Reykjavik is KEF; Stockholm is ARN; Bucharest is OTP). If Sophia prefers name-style codes (BNK etc.) it is a one-line change to the `code()` helper in `ticketData`, but they would not be real codes.
3. **Flight map is tall on phones, inside the flight section.** In the normal (not enlarged) state, when the screen is under 700px wide the map is about 0.85 x its width tall (`applyBig`, else branch) instead of the wide 800:300 strip, so the route and pins are readable without tapping Enlarge. The resize listener now works in both states. Desktop is unchanged. The map is still the hand-drawn coastline set (`LAND`); a real tile or country-border map was not possible because no map data or network was available when building. Ideas: embed Natural Earth country shapes (simplified) as a data string, or use a map library once deployed online.
4. **Vercel project**: `cloudberry.html` is `src/index.html` in `cloudberry-vercel.zip`. Build is `npm run build` (syntax check, copies to `dist/`), output `dist`, framework preset Other, no environment variables, no dependencies. Deploy steps are in the zip's README. The page was tested end to end in headless Chromium (19 checks, zero script errors) before M29; M29 was only syntax-checked, not re-rendered.
5. **Data moves per address**: the Vercel address has its own saved data; use Settings > Backup and restore to carry the passport over.

## M30 changes
1. **Passport is printed blank, then stamped.** `ppPage(pr,anim,bare)`: with `bare` the `.appr` stamp is rendered hidden. `printPassport` prints the blank page (about 2.7 s), then at 2.8 s the APPROVED stamp is pressed on with the rubber-stamp animation and thump (message "Stamping your passport..."), at 4.5 s "Passport approved!" with a chime, and the overlay closes at 5.3 s (Skip still ends it at once). The approved screen, passport control and saved image still show the stamp.
2. **Visa delete sound is a bubble pop** (`popBubble()`, replaces `ripPaper()`): a short sine blip rising fast in pitch plus a tiny high-passed noise click, straight to `ac.destination`, respects the Sounds setting.
3. **Landing routine hero** (the screen with no finished flight) shows the blueberry logo (`img.logo.big`, `LOGO`) instead of the bear and clover. The bear is still on the empty Flight screen (not asked for); Cozy Cabin and Lucky Start keep their station emoji.
4. **Checks clear by themselves**: `clearBoardChecks(withLanding)` untick every station to-do and the Lucky three. It runs in `land()` when a flight finishes (completed or early) and keeps the Landing Routine list ticked so she can still finish it after landing; `doBoard()` clears everything including Landing Routine when the next flight boards. The **Clear checks button and `ACT.clearChecks` were removed** (a leftover unused `.clrrow` CSS rule remains).
5. M30 was syntax-checked only, not re-rendered or heard.

## M31 changes (supersedes M30 item 1)
1. **Printer no longer stamps.** `printPassport` prints the blank passport (`ppPage(...,false,true)`, bare = stamp hidden), says "Passport printed!" and closes at 3.7 s as before. The APPROVED stamp is only pressed on in the "Passport approved!" screen (`issuedView`) and in passport control (`checkSheet(true)`).
2. **Explore the enlarged map.** When the map is enlarged: drag to pan, pinch or mouse wheel to zoom (about the finger or cursor), buttons **+ / - / Fit** top right (`ACT.mapZoom`, Fit returns to the whole route), hint text bottom left. Tapping the map no longer shrinks it, use the Shrink map button (`ACT.mapBig` ignores taps on `#f-map` while enlarged). Code: `MVIEW` (user view in degrees: cx, cy, w), `clampView`, `curView`, `setView`, `zoomAt`, `bindMapGestures`, `redrawMap`. While a gesture runs only the `viewBox` changes; 200 ms after it stops `setupMap` redraws land, pins and country labels at the new zoom so they stay a readable size and more labels appear when zoomed in. Zoom range: about 10 degrees wide up to the whole world; the view is clamped so it never goes past the poles. `MVIEW` resets on every Enlarge/Shrink.
3. **Map always fits the frame** (`setupMap` fit block): the whole route (plus 35% margin) is always inside the frame, even for the longest routes. The map can never show more than pole to pole; if a route is so wide that the frame would need to be taller than the sky, the frame is made shorter to match (`MAPASP` and the wrapper height are adjusted) instead of showing empty space. The SVG uses `preserveAspectRatio="xMidYMid slice"` and the wrapper has the sky colour as background, so there are no bars or stray pixels. Land is drawn in 3 copies (-360, 0, +360) so routes across the date line have no gaps.
4. **Tested** in headless Chromium (desktop 1100px and phone 375px, normal and enlarged): 8 very long routes (PH-IS, PH-AR, NZ-IS, AU-CA, JP-BR, ZA-NZ, CL-JP, IS-NZ) all fit inside the frame, never past the poles, frame gap 0 to 1 px; zoom, drag and wheel work; zero script errors.

## M32 change
The "After you land: Landing Routine" chip was removed from every boarding gate screen (mode cards, station list, station page): `landChip` in `renderBoarding` is now an empty string. The Landing Routine is still reached from the Landing screen after a flight. Syntax-checked only.

## M33 change
**Every time the passport is printed it is approved and stamped again.** After `printPassport` finishes, `showApproved(next)` opens an "Passport approved!" sheet (`approvedSheet`, class `approved`) with the passport and the APPROVED stamp animation, and a Continue button (`ACT.approvedOk`) that runs `next`. Three paths: first issue (unchanged, the full-screen `issuedView`), editing the passport from the Passport or Settings screens (print > approved > toast "Profile saved."; the screen behind is refreshed first), and editing during passport control before boarding (print > approved > "Ready to start?" > passport and ticket). Closing the approved sheet with the x skips `next` (for the boarding path, press Board again). The printer itself still prints the blank page. Syntax-checked only.

## M34 changes
1. The **Save my passport** button was removed from the Passport screen (only **Edit details** remains). `ACT.savePassport` was removed; the image-making function `savePassportSheet` is still in the file, unused.
2. The **bear was removed from the empty Flight screen** (the "no flight yet" card now has just the Go to the roulette button). `bearSVG` stays in the file for other uses.
3. **Packaging:** the project folder and ZIP are now simply named `cloudberry` (`cloudberry.zip`, unzips to a `cloudberry/` folder) so it can go straight to GitHub. Upload the contents of that folder to the repository root (index lives in `src/index.html`, Vercel settings are in `vercel.json`). Syntax-checked only.

## M35 change
The line "Time lapse flights do not count toward your streak." was removed from the This week card (Passport screen). The rule itself is unchanged: time lapse flights still do not count toward the streak, it is just no longer written on screen. Syntax-checked only.

## M36 packaging change
`cloudberry.zip` now contains only `index.html` (the whole app, identical to `src/index.html`), no `package.json` or `vercel.json`, because Sophia wanted it simple for GitHub. Vercel serves a lone `index.html` with zero setup (Framework Preset Other, no build command, no output directory, no environment variables). The fuller project (package.json, vercel.json, build script, local preview server, README) was kept in the working folder `cloudberry/` but is no longer in the download; it can be re-packaged on request.

## M37 packaging change (supersedes M36)
`cloudberry.zip` is the **complete deploy-ready project again** (index.html inside `src/`, `package.json`, `vercel.json`, build script, local preview server, README with deploy steps, `.gitignore`, `.env.example`, docs). It unzips to a folder named `cloudberry`; upload the **contents** of that folder to the root of the GitHub repo. Vercel settings: Framework Preset Other, Build Command `npm run build`, Output Directory `dist` (all already in `vercel.json`), no environment variables, no dependencies.

## IMPORTANT: published-page sandbox rule
The published artifact runs in a sandboxed iframe WITHOUT `allow-forms`, so native `<form>` submission is blocked and the submit event never fires (this made "Get my passport" and "Add your own step" do nothing). Never use `<form>`/`type="submit"`. Forms are `<div data-form="...">` with a `type="button" data-act="submitForm"` button; `submitForm(f)` handles them and Enter in a text input triggers it. Always test in a sandboxed iframe (`sandbox="allow-scripts allow-popups"`), not only as a plain page.

## Pomodoro and stopover rules (the core logic)
- 25 min focus, 5 min break, and a 15 min long break after every 4th focus block.
- A tiny leftover tail (10 min or less) is absorbed into the last focus block, so a 30 min session is one 30 min block.
- **Sessions of 180 min or more**: every long break becomes a **layover** (a stopover country). The plane sits parked at that country during the layover. Examples: 3 h = 1 stopover, 6 h = 2 stopovers.
- Stopover countries are chosen as the nearest country to the great-circle point at that moment's fraction of the route (never the home or destination country, never repeated).
- Plane progress counts flying minutes only (layover minutes freeze the plane).

## Code map (inside the `<script>` of `cloudberry.html`)
- State saved in `localStorage` key `cloudberry.v1`: `home`, `board` (daily station items, lucky three, note), `session` (current flight: segments, stops, elapsed, running), `passport` (entries), `prefs` (`sound`, `ff`), `wheel`.
- `RAW` = country table `[ISO code, name, city, lat, lon]`. Flags are made from the ISO code (regional indicator emoji).
- `buildSegments`, `planFlight`, `segAt`, `progressAt` = pomodoro and stopover logic.
- `STATIONS` and `GROUPS` = station definitions. Add a new station by adding an object here and its id in a group.
- `render*` functions build each screen; `ACT` holds all button handlers (buttons use `data-act`, navigation uses `data-go`, two-tap confirms use `data-confirm`).
- `tick()` runs every 250 ms: station timers, flight elapsed time, block changes, landing. Time uses real clock timestamps, so refreshing or backgrounding does not lose the flight.
- Design tokens are the `:root` CSS variables at the top (cream, ochre, cloudberry amber, clover, bear brown, sky, blush). Dark mode tokens are defined too.

## Checks done
- JavaScript syntax check passed.
- Planning logic tested for 30, 60, 120, 180, 240, 360 and 725 minute sessions: segments add up to the exact total, layovers appear only at 180 min or more, stopovers are unique.
- M3: JavaScript syntax check passed. Headless-browser test (Chromium via Playwright) passed with no errors: setup and lock, stations, roulette spin, board, take off, plane moving on the map, theme switching, profile create and save, passport.
- BUG FIXED (existed since v1): `.overlay{display:grid}` overrode the `hidden` attribute, so an invisible layer covered the whole app and nothing could be clicked. Fixed with a global `[hidden]{display:none!important}` rule. Never remove it.
- Still worth a look on a real phone: map zoom and coastline shapes (they are coarse), pin label overlap on short routes, and the new themes on phone.

## Known limits and notes
- Saved data is per browser and per device (no account, no syncing). Use Settings > Backup and restore to move it.
- Flag emojis do not render on some Windows computers (they show as two letters, like "PH"). The country names are always shown beside them.
- Destination study lengths are chosen by the user; "Real flight" uses an estimated flight time, not an airline schedule.
- Browser downloads, printing and mailto links do not work inside a published artifact, so nothing relies on them.

## Ideas for next milestones (not built)
- Soft ambient sounds or an in-flight playlist link.
- Cat-themed mascot variants.

## Publishing
M29 is published as a private artifact (new link, the old v10 link could no longer be updated): https://claude.ai/artifact/5Qb9tABYP7jPDATCCH1sC1 . To update, pass it as `url` (or use action "edit"). Saved data is per link, so use Settings > Backup and restore to carry it over. Older notes follow.
Published as a private artifact, **version 10 (M18)**: https://claude.ai/artifact/SDe8FW6JtZsiMAz3Sobpq3 (new link; saved data is per link, so use Settings > Backup and restore to carry passport and stamps over). Older links: UkaVT8tdcX91qohTc7sv2W, TxsETGTr9fguVeP65q4A2p (old v1 build). Previous note follows.
https://claude.ai/artifact/UkaVT8tdcX91qohTc7sv2W

The version 2 link (VssEBtaCW5Gs5n4cehtGEL) could no longer be opened from a new chat, so version 3 is a new artifact. Version 1 was TxsETGTr9fguVeP65q4A2p. Saved data is per link, so passport and stamps from an old link do not carry over; use Settings > Backup and restore (copy on the old link, restore on the new one).
To update later, edit `cloudberry.html` and republish to the version 3 URL (pass it as `url`; if that fails, publish a new artifact and record the new link here).

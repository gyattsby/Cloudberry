// Cloudberry build script.
// The app is a single self-contained HTML page (CSS, JS, images all inline),
// so "building" = checking it is healthy, then copying src/ into dist/.
import { cpSync, rmSync, mkdirSync, readFileSync, statSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import vm from 'node:vm';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const src = join(root, 'src');
const dist = join(root, 'dist');
const entry = join(src, 'index.html');

const fail = (msg) => { console.error('\n✖ Build failed: ' + msg + '\n'); process.exit(1); };

if (!existsSync(entry)) fail('src/index.html is missing.');
const html = readFileSync(entry, 'utf8');

// 1. Sanity checks on the page.
if (!/<title>\s*Cloudberry\s*<\/title>/i.test(html)) fail('page <title> "Cloudberry" not found.');
if (!html.includes('</html>')) fail('index.html looks truncated (no closing </html>).');

// 2. Syntax-check every inline <script> so a typo can never ship.
const scripts = [...html.matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi)].map((m) => m[1]);
if (!scripts.length) fail('no inline <script> found.');
scripts.forEach((code, i) => {
  try { new vm.Script(code, { filename: `inline-script-${i + 1}.js` }); }
  catch (e) { fail(`JavaScript syntax error in inline script ${i + 1}: ${e.message}`); }
});

// 3. Copy src/ -> dist/
rmSync(dist, { recursive: true, force: true });
mkdirSync(dist, { recursive: true });
cpSync(src, dist, { recursive: true });

const kb = (statSync(join(dist, 'index.html')).size / 1024).toFixed(0);
console.log(`✔ Syntax check passed (${scripts.length} inline script${scripts.length > 1 ? 's' : ''})`);
console.log(`✔ Built dist/index.html (${kb} KB)`);
console.log('✔ Build complete. Output directory: dist/');
